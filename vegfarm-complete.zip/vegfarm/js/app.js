// js/app.js — App router & init

const PAGE_INIT = {
  dashboard: loadDashboard,
  seeds: initSeeds,
  plots: initPlots,
  problems: initProblems,
  calendar: initCalendar,
  todos: initTodos,
  finance: initFinance,
  customers: initCustomers
};

const initialized = new Set();

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.bottom-nav a').forEach(a => a.classList.remove('active'));

  document.getElementById(`page-${pageId}`).classList.add('active');
  document.getElementById(`nav-${pageId}`).classList.add('active');

  window.scrollTo(0, 0);

  // Init page on first visit, refresh dashboard/calendar always
  if (!initialized.has(pageId)) {
    PAGE_INIT[pageId]?.();
    initialized.add(pageId);
  } else if (pageId === 'customers') {
    loadCustomers();
  } else if (pageId === 'finance') {
    loadFinanceSummary();
  } else if (pageId === 'dashboard') {
    loadDashboard();
  } else if (pageId === 'calendar') {
    renderCalendar();
  } else if (pageId === 'plots') {
    loadAllPlots();
  } else if (pageId === 'problems') {
    loadProblemDatabase();
  } else if (pageId === 'todos') {
    loadTodos();
  }

  location.hash = pageId;
}

document.addEventListener('DOMContentLoaded', () => {
  // Set today's date in nav
  const today = new Date();
  document.getElementById('nav-date').textContent = today.toLocaleDateString('th-TH', {
    weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
  });

  // Bottom nav clicks
  document.querySelectorAll('.bottom-nav a').forEach(a => {
    a.addEventListener('click', (e) => {
      e.preventDefault();
      showPage(a.dataset.page);
    });
  });

  // Initial page from hash or default
  const hash = location.hash.replace('#', '');
  showPage(PAGE_INIT[hash] ? hash : 'dashboard');
});
